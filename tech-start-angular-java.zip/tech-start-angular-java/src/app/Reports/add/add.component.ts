import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../../Service/service.service';
import { Invoice } from 'src/app/Modelo/Invoice';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  persona:Invoice = new Invoice();
  constructor(private service:ServiceService, private router:Router) { }

  ngOnInit(): void {
  }

  Guardar(persona:Invoice) {

	  this.service.createInvoice(persona).subscribe(data=> {
		  alert("Se agrego con exito");
		  this.router.navigate(["listar"]);
	  });
  }
}

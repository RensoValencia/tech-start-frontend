import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../../Service/service.service';
import { Distributor } from 'src/app/Modelo/Distributor';

@Component({
  selector: 'app-list-distributor',
  templateUrl: './list-distributor.component.html',
  styleUrls: ['./list-distributor.component.css']
})
export class ListReportDistributor implements OnInit {

    distributors:Distributor[];
    constructor(private service:ServiceService, private router:Router) {

    }

    ngOnInit(): void {
      this.service.getListDistributors()
      .subscribe(data=> {
      this.distributors = data;
      });
    }

}

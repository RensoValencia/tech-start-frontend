import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../../Service/service.service';
import { Invoice } from 'src/app/Modelo/Invoice';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  persona:Invoice = new Invoice();
  constructor(private router:Router, private service:ServiceService) { }

  ngOnInit(): void {
	  this.Editar();
  }

  Editar() {
	  let id = localStorage.getItem("id");

	  if(null != id && typeof id != "undefined") {

		  this.service.getInvoiceId(id)
		  .subscribe(data=>{
			  this.persona = data;
		  });
	  }
  }

  Actualizar(persona:Invoice) {
	  this.service.updateInvoice(persona)
	  .subscribe(data=>{
			  this.persona = data;
			  alert("Se actualizo con exito");
			  this.router.navigate(["listar"]);
		  });;
  }

}

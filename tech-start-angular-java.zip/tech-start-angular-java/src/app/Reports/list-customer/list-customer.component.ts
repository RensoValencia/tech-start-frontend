import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../../Service/service.service';
import { Customer } from 'src/app/Modelo/Customer';

@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.css']
})
export class ListReportCustomer implements OnInit {

    customers:Customer[];
    constructor(private service:ServiceService, private router:Router) {

    }

    ngOnInit(): void {
      this.service.getListCustomers()
      .subscribe(data=> {
      this.customers = data;
      });
    }

}

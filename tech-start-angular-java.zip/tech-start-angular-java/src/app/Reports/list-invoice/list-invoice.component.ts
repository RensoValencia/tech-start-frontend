import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../../Service/service.service';
import { Invoice } from 'src/app/Modelo/Invoice';

@Component({
  selector: 'app-list-invoice',
  templateUrl: './list-invoice.component.html',
  styleUrls: ['./list-invoice.component.css']
})
export class ListReportInvoice implements OnInit {

    invoices:Invoice[];
    constructor(private service:ServiceService, private router:Router) {

    }

    ngOnInit(): void {
      this.service.getListInvoices()
      .subscribe(data=> {
      this.invoices = data;
      });
    }

    editInvoice(invoice:Invoice) {
      localStorage.setItem("id", invoice.id.toString());
      this.router.navigate(["edit"]);
    }

    deleteInvoice(invoice:Invoice) {
      this.service.deleteInvoice(invoice)
      .subscribe(data=> {
      this.invoices = this.invoices.filter(p=>p!==invoice);
      alert("use deleted");
      });
    }
}

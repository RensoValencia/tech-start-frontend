import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Invoice } from '../Modelo/Invoice';
import { Distributor } from '../Modelo/Distributor';
import { Customer } from '../Modelo/Customer';
import { Product } from '../Modelo/Product';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private http:HttpClient) { }

  UrlInvoice='http://localhost:7070/report/by-invoice';
  UrlDistributor='http://localhost:7070/report/by-distributor';
  UrlCustomer='http://localhost:7070/report/by-customer-location';
  UrlProduct='http://localhost:7070/report/by-product';

  getListInvoices() {
	  return this.http.get<Invoice[]>(this.UrlInvoice);
  }

  getListDistributors() {
	  return this.http.get<Distributor[]>(this.UrlDistributor);
  }

  getListCustomers() {
	  return this.http.get<Customer[]>(this.UrlCustomer);
  }

  getListProducts() {
	  return this.http.get<Product[]>(this.UrlProduct);
  }

  createInvoice(invoice:Invoice) {
	  return this.http.post<Invoice>(this.UrlInvoice, invoice);
  }

  getInvoiceId(id:string) {
	  return this.http.get<Invoice>(this.UrlInvoice + "/" + id);
  }

  updateInvoice(invoice:Invoice) {
	  return this.http.put<Invoice>(this.UrlInvoice + "/" + invoice.id, invoice);
  }

  deleteInvoice(invoice:Invoice) {
	  return this.http.delete<Invoice>(this.UrlInvoice + "/" + invoice.id);
  }
}

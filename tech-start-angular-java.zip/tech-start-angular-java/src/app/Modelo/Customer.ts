export class Customer{
  name:string;
	address:string;
	contact:string;
  groupName:string;
}

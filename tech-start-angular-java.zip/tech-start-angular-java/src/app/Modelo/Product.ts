export class Product{
  id:string;
	description:string;
	productCode:string;
  manufacturerId:string;
  distributorId:string;
  distributorData:string;
  manufacturerData:string;
}

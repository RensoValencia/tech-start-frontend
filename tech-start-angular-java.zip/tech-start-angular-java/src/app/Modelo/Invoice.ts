export class Invoice{
	id:string;
	invoiceNumber:string;
	purchaseDate:string;
	totalPurchase:number;
  customerId:number;
  distributorId:number;
}
